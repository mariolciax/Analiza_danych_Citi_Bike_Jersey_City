library("dplyr")
library("plotly")
library("RColorBrewer")
library("rCharts")
library("ggplot2")
library("reshape2")
library("devtools")
library("mplot")
options(repr.plot.width = 7)
options(repr.plot.height = 5)
options(jupyter.rich_display = FALSE)
options(width = 120)

marzec20_JC<-read.csv("JC-202003-citibike-tripdata.csv")
marzec19_JC<-read.csv("JC-201903-citibike-tripdata.csv")
marzec18_JC<-read.csv("JC-201803-citibike-tripdata.csv")

podzial_uzytkownikow_ze_wzgledu_na_wiek<-function(){
m18<-group_by(marzec18_JC,birth.year)
m18<-tally(m18)
m18<-rename(m18,marzec_2018=n)
m19<-group_by(marzec19_JC,birth.year)
m19<-tally(m19)
m19<-rename(m19,marzec_2019=n)
m20<-group_by(marzec20_JC, birth.year)
m20<-tally(m20)
m20<-rename(m20,marzec_2020=n)
t<-full_join(m19,m20,by=c("birth.year"="birth.year"))
t<-full_join(m18,t,by=c("birth.year"="birth.year"))
t<-mutate(t,marzec_2018=ifelse(is.na(marzec_2018),0,marzec_2018))
t<-mutate(t,marzec_2019=ifelse(is.na(marzec_2019),0,marzec_2019))
t<-mutate(t,marzec_2020=ifelse(is.na(marzec_2020),0,marzec_2020))
t<-arrange(t,birth.year)
t<-mutate(t,birth.year=as.character(birth.year))

m1<-mPlot(x="birth.year",y=c("marzec_2018","marzec_2019","marzec_2020"),type="Line",
          data=t,pointSize=0, lineWidth=1,lineColors=c("red","chartreuse","blue"))
m1
}