aplikacja<-function(){
  library("shiny")
  runApp('aplikacja')
}