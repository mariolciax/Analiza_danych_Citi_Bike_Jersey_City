najczesciej_wybierana_stacja <- function(){
  styczen19 <- read.csv("JC-201901-citibike-tripdata.csv")
  luty19 <- read.csv("JC-201902-citibike-tripdata.csv")
  marzec19 <- read.csv("JC-201903-citibike-tripdata.csv")
  marzec18 <- read.csv("JC-201803-citibike-tripdata.csv")
  styczen20 <- read.csv("JC-202001-citibike-tripdata.csv")
  luty20 <- read.csv("JC-202002-citibike-tripdata.csv")
  marzec20 <- read.csv("JC-202003-citibike-tripdata.csv")
library("data.table")
library("dplyr")
  marzec19_station <- select(marzec19, start.station.name, end.station.name)
  marzec19_station_a<- as.vector(select(marzec19, start.station.name))
  marzec19_station_b<- as.vector(select(marzec19, end.station.name))
  vector<-unlist( c(marzec19_station_a,marzec19_station_b))
  d<- as.data.frame(vector)
  d<- d %>%
    group_by(vector) %>%
    tally()
  marzec19_station <- as.vector(top_n(d, 1))
  
  marzec20_station <- select(marzec20, start.station.name, end.station.name)
  marzec20_station_a<- as.vector(select(marzec20, start.station.name))
  marzec20_station_b<- as.vector(select(marzec20, end.station.name))
  vector<-unlist( c(marzec20_station_a,marzec20_station_b))
  d<- as.data.frame(vector)
  d<- d %>%
    group_by(vector) %>%
    tally()
  marzec20_station <- as.vector(top_n(d, 1))
  
  styczen20_station <- select(styczen20, start.station.name, end.station.name)
  styczen20_station_a<- as.vector(select(styczen20, start.station.name))
  styczen20_station_b<- as.vector(select(styczen20, end.station.name))
  vector<-unlist( c(styczen20_station_a,styczen20_station_b))
  d<- as.data.frame(vector)
  d<- d %>%
    group_by(vector) %>%
    tally()
  styczen20_station <- as.vector(top_n(d, 1))
  
  luty20_station <- select(luty20, start.station.name, end.station.name)
  luty20_station_a<- as.vector(select(luty20, start.station.name))
  luty20_station_b<- as.vector(select(luty20, end.station.name))
  vector<-unlist( c(luty20_station_a,luty20_station_b))
  luty20_station <- as.data.frame(vector)
  luty20_station <- luty20_station  %>%
    group_by(vector) %>%
    tally()
  luty20_station <- as.vector(top_n(d, 1))
  
  marzec18_station <- select(marzec18, start.station.name, end.station.name)
  marzec18_station_a<- as.vector(select(marzec18, start.station.name))
  marzec18_station_b<- as.vector(select(marzec18, end.station.name))
  vector<-unlist( c(marzec18_station_a,marzec18_station_b))
  marzec18_station <- as.data.frame(vector)
  marzec18_station<-marzec18_station %>%
    group_by(vector) %>%
    tally()
  marzec18_station <- as.vector(top_n(d, 1))
  
  dane <- c(marzec20_station$n, marzec19_station$n, luty20_station$n,
            styczen20_station$n, marzec18_station$n)
  
  names(dane) <- c("marzec 2020","marzec 2019","luty 2020", "styczen 2020", "marzec 2018")
  pie(dane,main=as.character(unlist(marzec19_station[1,1])), col=rainbow(20)[15:20])
}